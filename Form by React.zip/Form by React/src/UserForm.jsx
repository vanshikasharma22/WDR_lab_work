import React, { useState } from 'react';

function UserForm({ onFormUpdate }) {
    const [formUser, setFormUser] = useState({
        username: '',
        standard: '',
        age: '',
        email: '',
        city: '',
    });

    function handleChange(event) {
        const { name, value } = event.target;
        setFormUser(prev => {
            const updated = { ...prev, [name]: value };
            onFormUpdate(updated); // Update parent when form changes
            return updated;
        });
    }

    return (
        <div>
            <h2>User Form</h2>
            <input type="text" name="username" value={formUser.username}
                placeholder="Enter your name" onChange={handleChange} /><br />
            <input type="text" name="standard" value={formUser.standard}
                placeholder="Enter standard" onChange={handleChange} /><br />
            <input type="number" name="age" value={formUser.age}
                placeholder="Enter age" onChange={handleChange} /><br />
            <input type="email" name="email" value={formUser.email}
                placeholder="Enter email" onChange={handleChange} /><br />
            <input type="text" name="city" value={formUser.city}
                placeholder="Enter city" onChange={handleChange} /><br />
        </div>
    );
}

export default UserForm;
