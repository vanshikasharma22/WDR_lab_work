import React, { useState } from 'react';
import UserForm from './UserForm';
import UserDisplay from './UserDisplay';

function App() {
    const [user, setUser] = useState({
        username: '',
        standard: '',
        age: '',
        email: '',
        city: '',
    });

    const handleFormUpdate = (updatedUser) => {
        setUser(updatedUser);
    };

    return (
        <div>
            <UserForm onFormUpdate={handleFormUpdate} />
            <UserDisplay user={user} />
        </div>
    );
}

export default App;
